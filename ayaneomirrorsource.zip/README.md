# DS Mirror
Open in Android Studio, build, install.
1. Shizuku (root mode, "Start on boot" enabled) must be running; grant DS Mirror access when prompted.
2. Launch DS Mirror ON THE BOTTOM SCREEN, e.g. from a root shell:
   su -c "am start --display <bottomId> -n com.example.dsmirror/.MainActivity"
   (find ids with: dumpsys display | grep mDisplayId)
Top display is auto-picked (display 0 if the app is on another display).
