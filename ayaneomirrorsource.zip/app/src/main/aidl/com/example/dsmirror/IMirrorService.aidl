package com.example.dsmirror;
import android.view.Surface;
import android.view.MotionEvent;
interface IMirrorService {
    void destroy() = 16777114;
    void startMirror(in Surface surface, int topDisplayId, int w, int h) = 1;
    void stopMirror() = 2;
    String getLastError() = 4;
    String prepareRaw() = 5;
    String selectRaw(String name, int rotation, int dispW, int dispH) = 6;
    String foregroundPackage(int displayId) = 10;
    String inputCmd(String op, int x, int y, int displayId) = 9;
    oneway void shellGesture(int x1, int y1, int x2, int y2, int durMs, int displayId) = 8;
    oneway void rawTouch(int action, int actionIndex, in int[] ids, in float[] xs, in float[] ys) = 7;
    String inject(in MotionEvent event, int topDisplayId) = 3;
}
