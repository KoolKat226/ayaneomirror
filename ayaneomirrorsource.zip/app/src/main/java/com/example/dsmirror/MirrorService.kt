package com.example.dsmirror

import android.graphics.Rect
import android.os.IBinder
import android.view.InputEvent
import android.view.MotionEvent
import android.util.Log
import android.view.Surface
import kotlin.system.exitProcess

/**
 * Runs in the privileged (root) process started by Shizuku. No hidden-API restrictions apply here.
 * Mirrors the top display's layer stack straight into the bottom SurfaceView via SurfaceFlinger
 * (no encode, no copy through the app), and injects touch events onto the top display.
 */
class MirrorService : IMirrorService.Stub() {
    private val scCls = Class.forName("android.view.SurfaceControl")
    private var token: IBinder? = null

    private val inputMgr: Any by lazy {
        val b = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java)
            .invoke(null, "input") as IBinder
        Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, b)!!
    }
    private val injectM by lazy {
        Class.forName("android.hardware.input.IInputManager")
            .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
    }
    private val setDisplayIdM by lazy {
        MotionEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
    }

    private fun call(target: Any?, cls: Class<*>, name: String, vararg a: Any?): Any? =
        cls.methods.first { it.name == name && it.parameterTypes.size == a.size }.invoke(target, *a)

    private fun layerStack(displayId: Int): Int {
        val g = Class.forName("android.hardware.display.DisplayManagerGlobal")
            .getMethod("getInstance").invoke(null)!!
        val info = g.javaClass.getMethod("getDisplayInfo", Int::class.javaPrimitiveType).invoke(g, displayId)!!
        return info.javaClass.getField("layerStack").getInt(info)
    }

    override fun startMirror(surface: Surface, topDisplayId: Int, w: Int, h: Int) {
        stopMirror()
        val t = call(null, scCls, "createDisplay", "ds-mirror", false) as IBinder
        token = t
        val stack = layerStack(topDisplayId)
        val rect = Rect(0, 0, w, h)
        fun ops(target: Any?, cls: Class<*>) {
            call(target, cls, "setDisplaySurface", t, surface)
            call(target, cls, "setDisplayProjection", t, 0, rect, rect)
            call(target, cls, "setDisplayLayerStack", t, stack)
        }
        try { // classic static transaction (Android <= 13, many 14 builds)
            call(null, scCls, "openTransaction")
            try { ops(null, scCls) } finally { call(null, scCls, "closeTransaction") }
        } catch (e: NoSuchElementException) { // Transaction-object API fallback
            val txCls = Class.forName("android.view.SurfaceControl\$Transaction")
            val tx = txCls.getConstructor().newInstance()
            ops(tx, txCls)
            call(tx, txCls, "apply")
        }
    }

    override fun stopMirror() {
        token?.let { runCatching { call(null, scCls, "destroyDisplay", it) } }
        token = null
    }

    @Volatile private var lastError = ""
    override fun getLastError(): String { val e = lastError; lastError = ""; return if (e.isEmpty()) "ok frames=$frames" else e }
    @Volatile private var frames = 0

    override fun inject(event: MotionEvent, topDisplayId: Int): String {
        return try {
            setDisplayIdM.invoke(event, topDisplayId)
            val ok = injectM.invoke(inputMgr, event, 1) // 1 = wait for dispatch result (diagnostic; 0 = async)
            val r = "ok=$ok act=${event.actionMasked} disp=${MotionEvent::class.java.getMethod("getDisplayId").invoke(event)} xy=${event.x.toInt()},${event.y.toInt()} dev=${event.deviceId} uid=${android.os.Process.myUid()}"
            Log.i("DSMirror", r)
            r
        } catch (t: Throwable) {
            val c = t.cause ?: t
            Log.e("DSMirror", "inject failed", c)
            "ERR $c"
        } finally {
            event.recycle()
        }
    }

    // ---------- raw evdev path: write touches straight into the top screen's touch device ----------
    private class Node(val path: String) {
        var name = ""; var xMax = 0; var yMax = 0; var slots = 10; var pMax = 0; var mMax = 0
    }
    private val nodes = LinkedHashMap<String, Node>()
    private var cur: Node? = null
    private var evOut: java.io.FileOutputStream? = null
    private var rot = 0; private var dW = 1; private var dH = 1
    private var trackId = 0; private var downCount = 0
    private val buf = java.nio.ByteBuffer.allocate(24 * 128).order(java.nio.ByteOrder.nativeOrder())

    private fun ev(type: Int, code: Int, value: Int) {
        buf.putLong(0); buf.putLong(0)               // timestamp: kernel fills it in
        buf.putShort(type.toShort()); buf.putShort(code.toShort()); buf.putInt(value)
    }

    @Synchronized
    override fun prepareRaw(): String {
        nodes.clear()
        val p = Runtime.getRuntime().exec(arrayOf("/system/bin/getevent", "-p"))
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor()
        val abs = Regex("([0-9a-f]{4})\\s*:\\s*value\\s+-?\\d+,\\s*min\\s+(-?\\d+),\\s*max\\s+(-?\\d+)")
        val section = Regex("^[A-Z_]+ \\([0-9a-f]{4}\\):")
        var node: Node? = null
        var inAbs = false
        for (line in text.lines()) {
            val t = line.trim()
            if (t.startsWith("add device")) { node = Node(t.substringAfter(": ").trim()); inAbs = false; continue }
            val n = node ?: continue
            if (t.startsWith("name:")) { n.name = t.substringAfter('"').substringBeforeLast('"'); nodes[n.name] = n; continue }
            if (section.containsMatchIn(t)) inAbs = t.startsWith("ABS")
            if (inAbs) abs.find(t)?.let { m ->
                val max = m.groupValues[3].toInt()
                when (m.groupValues[1]) {
                    "0035" -> n.xMax = max; "0036" -> n.yMax = max
                    "002f" -> n.slots = max + 1; "003a" -> n.pMax = max; "0030" -> n.mMax = max
                }
            }
        }
        return nodes.values.filter { it.xMax > 0 }.joinToString { "${it.name}@${it.path} ${it.xMax}x${it.yMax}" }
    }

    @Synchronized
    override fun selectRaw(name: String, rotation: Int, dispW: Int, dispH: Int): String {
        val n = nodes[name] ?: return "no node '$name' (have ${nodes.keys})"
        if (n.xMax <= 0 || n.yMax <= 0) return "'$name' has no multitouch axes"
        return try {
            runCatching { evOut?.close() }
            evOut = java.io.FileOutputStream(n.path)
            cur = n; rot = rotation; dW = dispW; dH = dispH; downCount = 0
            "OK ${n.name} ${n.path} ${n.xMax}x${n.yMax} slots=${n.slots} p=${n.pMax} rot=$rotation"
        } catch (t: Throwable) { "open ${n.path} failed: $t" }
    }

    @Synchronized
    override fun rawTouch(action: Int, actionIndex: Int, ids: IntArray, xs: FloatArray, ys: FloatArray) {
        val n = cur ?: return
        try {
            buf.clear()
            fun pos(i: Int) {
                val fx = (xs[i] / dW).coerceIn(0f, 1f); val fy = (ys[i] / dH).coerceIn(0f, 1f)
                // inverse of InputReader's display-orientation transform
                val (rx, ry) = when (rot) {
                    1 -> (1 - fy) to fx
                    2 -> (1 - fx) to (1 - fy)
                    3 -> fy to (1 - fx)
                    else -> fx to fy
                }
                ev(3, 0x35, (rx * n.xMax).toInt()); ev(3, 0x36, (ry * n.yMax).toInt())
            }
            when (action and 0xff) {
                0, 5 -> { // DOWN / POINTER_DOWN
                    val i = if ((action and 0xff) == 0) 0 else actionIndex
                    ev(3, 0x2f, ids[i] % n.slots); ev(3, 0x39, (++trackId) and 0xffff); pos(i)
                    if (n.pMax > 0) ev(3, 0x3a, maxOf(1, n.pMax / 2))
                    if (n.mMax > 0) ev(3, 0x30, minOf(8, n.mMax))
                    if (downCount++ == 0) ev(1, 0x14a, 1)
                }
                2 -> for (i in ids.indices) { ev(3, 0x2f, ids[i] % n.slots); pos(i) }
                1, 6 -> { // UP / POINTER_UP
                    val i = if ((action and 0xff) == 1) 0 else actionIndex
                    ev(3, 0x2f, ids[i] % n.slots); ev(3, 0x39, -1)
                    if (--downCount <= 0) { downCount = 0; ev(1, 0x14a, 0) }
                }
                3 -> { // CANCEL
                    for (i in ids.indices) { ev(3, 0x2f, ids[i] % n.slots); ev(3, 0x39, -1) }
                    downCount = 0; ev(1, 0x14a, 0)
                }
                else -> return
            }
            ev(0, 0, 0) // SYN_REPORT
            evOut?.write(buf.array(), 0, buf.position())
            frames++
        } catch (t: Throwable) { lastError = "raw: $t" }
    }

    // ---------- slow-but-proven path: replay the gesture with the system `input` command ----------
    private val shellExec = java.util.concurrent.Executors.newSingleThreadExecutor()

    override fun shellGesture(x1: Int, y1: Int, x2: Int, y2: Int, durMs: Int, displayId: Int) {
        shellExec.execute {
            try {
                val moved = Math.abs(x2 - x1) + Math.abs(y2 - y1) > 24
                val cmd = if (!moved && durMs < 400)
                    arrayOf("/system/bin/input", "-d", "$displayId", "tap", "$x1", "$y1")
                else
                    arrayOf("/system/bin/input", "-d", "$displayId", "swipe", "$x1", "$y1", "$x2", "$y2", "${maxOf(durMs, 1)}")
                Runtime.getRuntime().exec(cmd).waitFor()
            } catch (t: Throwable) { lastError = "shell: $t" }
        }
    }

    // ---------- run the system `input` command (the thing that works from your terminal) ----------
    private fun runInput(vararg a: String): String {
        val t0 = System.nanoTime()
        val p = ProcessBuilder(listOf("/system/bin/input") + a).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        val code = p.waitFor()
        val ms = (System.nanoTime() - t0) / 1_000_000
        return if (code == 0 && out.isEmpty()) "ok ${ms}ms" else "ERR exit=$code ${ms}ms out=${out.take(300)}"
    }

    @Synchronized
    override fun inputCmd(op: String, x: Int, y: Int, displayId: Int): String = try {
        when (op) {
            "i" -> java.io.File("/system/bin/input").readText().take(300)
            "d" -> runInput("-d", "$displayId", "motionevent", "DOWN", "$x", "$y")
            "m" -> runInput("-d", "$displayId", "motionevent", "MOVE", "$x", "$y")
            "u" -> runInput("-d", "$displayId", "motionevent", "UP", "$x", "$y")
            else -> runInput("-d", "$displayId", "tap", "$x", "$y")
        }
    } catch (t: Throwable) { "ERR ${t.cause ?: t}" }

    // ---------- which app is in front on a given display (for per-app layouts) ----------
    override fun foregroundPackage(displayId: Int): String = try {
        val p = ProcessBuilder("/system/bin/dumpsys", "activity", "activities").redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText(); p.waitFor()
        var start = text.indexOf("Display #$displayId (activities from top to bottom)")
        if (start < 0) start = text.indexOf("Display #$displayId")
        if (start < 0) "" else {
            val next = text.indexOf("Display #", start + 12)
            val block = text.substring(start, if (next < 0) text.length else next)
            Regex("ActivityRecord\\{[0-9a-f]+ u\\d+ ([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1) ?: ""
        }
    } catch (t: Throwable) { "" }

    override fun destroy() { stopMirror(); exitProcess(0) }
}
