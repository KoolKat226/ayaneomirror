package com.example.dsmirror

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

/** Letterboxes itself to the top display's aspect ratio so touch mapping is a pure scale. */
class AspectSurfaceView(c: Context) : SurfaceView(c) {
    var ratio = 1f
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec); val maxH = MeasureSpec.getSize(hSpec)
        var w = maxW; var h = (w / ratio).toInt()
        if (h > maxH) { h = maxH; w = (h * ratio).toInt() }
        setMeasuredDimension(w, h)
    }
}

class MainActivity : Activity(), SurfaceHolder.Callback {
    private var svc: IMirrorService? = null          // Shizuku (root) service: mirroring + touch
    private lateinit var root: FrameLayout
    private lateinit var sv: AspectSurfaceView
    private lateinit var status: TextView
    private lateinit var editBtn: TextView
    private lateinit var slotBtns: List<TextView>
    private lateinit var closeBtn: TextView
    private var slot = 0   // which of the 4 saved configurations is active for the current app
    private var topId = 0; private var topW = 1; private var topH = 1
    private var surfaceOk = false

    // layout (per app on the top screen)
    private var editing = false
    private var scale = 1f; private var tx = 0f; private var ty = 0f
    private var lastX = 0f; private var lastY = 0f
    private var curPkg = ""
    @Volatile private var alive = true
    @Volatile private var resumed = false
    private var poller: Thread? = null

    // touch
    private var live = true            // real-time multi-touch (long-press the circle to switch to tap/swipe mode)
    @Volatile private var rawReady = false
    private var rawTried = false; private var rawOk = false; private var rawName: String? = null; private var rawRot = -1
    private var streamRaw = false
    private val activePtrs = LinkedHashSet<Int>()
    private var gx = 0; private var gy = 0; private var gt = 0L
    private var gvx = 0f; private var gvy = 0f
    private var cancelled = false

    private val hideStatus = Runnable { status.visibility = View.INVISIBLE }

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, MirrorService::class.java.name))
            .daemon(false).processNameSuffix("mirror").version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            svc = IMirrorService.Stub.asInterface(b); startMirror(); show("Connected")
            Thread {
                val r = runCatching { svc?.prepareRaw() }.getOrElse { "ERR $it" } ?: ""
                rawReady = r.isNotEmpty() && !r.startsWith("ERR")
                if (!rawReady) show("Live touch unavailable ($r) – using tap/swipe")
            }.start()
            startPoller()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null; show("Service lost") }
    }
    private val binderL = Shizuku.OnBinderReceivedListener { connect() }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, r ->
        if (r == PackageManager.PERMISSION_GRANTED) connect() else show("Shizuku permission denied")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pickTopDisplay()

        sv = AspectSurfaceView(this).apply { ratio = topW.toFloat() / topH }
        sv.holder.setFixedSize(topW, topH) // 1:1 buffer; compositor scales to the view
        sv.holder.addCallback(this)
        sv.setOnTouchListener { v, e -> if (editing) false else { forward(v, e); true } }

        // small, non-interactive label (fades out); wrap_content so it can never cover the screen
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; setPadding(12, 6, 12, 6)
            setBackgroundColor(0x99000000.toInt())
            isClickable = false; isFocusable = false; visibility = View.INVISIBLE
        }

        val d = resources.displayMetrics.density
        val margin = (12 * d).toInt(); val gap = (8 * d).toInt()
        fun dot(sizeDp: Int) = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 9f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setStroke(maxOf(1, d.toInt()), 0x77FFFFFF) // faint rim so black dots show on black
            }
            alpha = 0.9f
            layoutParams = android.widget.LinearLayout.LayoutParams((sizeDp * d).toInt(), (sizeDp * d).toInt())
                .apply { rightMargin = gap }
        }
        editBtn = dot(30).apply {
            setOnClickListener { setEditing(!editing) }
            setOnLongClickListener {
                if (!editing) {
                    live = !live; rawTried = false
                    show(if (live) "LIVE multi-touch" else "TAP / SWIPE mode (fires when you lift)")
                }
                true
            }
        }
        slotBtns = (0..3).map { i -> dot(22).apply { text = "${i + 1}"; setOnClickListener { setSlot(i) } } }
        closeBtn = dot(24).apply {
            (background as GradientDrawable).setColor(CLOSE)
            setOnClickListener { finishAndRemoveTask() }
        }
        val controls = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(closeBtn); addView(editBtn); slotBtns.forEach { addView(it) }
        }

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(det: ScaleGestureDetector): Boolean {
                val ns = (scale * det.scaleFactor).coerceIn(0.3f, 5f)
                val f = ns / scale
                val cx = sv.left + sv.width / 2f; val cy = sv.top + sv.height / 2f
                tx = det.focusX - (det.focusX - (cx + tx)) * f - cx   // keep the point between your fingers fixed
                ty = det.focusY - (det.focusY - (cy + ty)) * f - cy
                scale = ns; applyView(); return true
            }
        })
        val doubleTap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean { scale = 1f; tx = 0f; ty = 0f; applyView(); return true }
        })

        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(sv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
            addView(controls, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
                .apply { setMargins(margin, margin, margin, margin) })
            setOnTouchListener { _, e ->
                if (!editing) return@setOnTouchListener false
                scaleDetector.onTouchEvent(e); doubleTap.onTouchEvent(e)
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y }
                    MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress && e.pointerCount == 1) {
                        tx += e.x - lastX; ty += e.y - lastY; lastX = e.x; lastY = e.y; applyView()
                    }
                    MotionEvent.ACTION_POINTER_UP -> { // re-anchor the finger that's still down
                        val i = if (e.actionIndex == 0) 1 else 0; lastX = e.getX(i); lastY = e.getY(i)
                    }
                }
                true
            }
        }
        setContentView(root)
        loadLayout("")
        refreshBtn()
        window.setDecorFitsSystemWindows(false)
        window.insetsController?.hide(WindowInsets.Type.systemBars())
        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addRequestPermissionResultListener(permL)
        show("Left button edits the layout · 1-4 pick a saved configuration")
    }

    private fun show(msg: String) = runOnUiThread {
        status.text = msg; status.visibility = View.VISIBLE
        status.removeCallbacks(hideStatus); status.postDelayed(hideStatus, 3000)
    }

    private fun refreshBtn() {
        (editBtn.background as GradientDrawable).setColor(if (editing) ORANGE else BLACK)
        slotBtns.forEachIndexed { i, b ->
            val on = i == slot
            (b.background as GradientDrawable).setColor(if (on) Color.WHITE else BLACK)
            b.setTextColor(if (on) Color.BLACK else Color.WHITE)
        }
    }

    // ---------- edit mode ----------
    private fun setEditing(on: Boolean) {
        if (on) cancelRaw()
        editing = on; cancelled = true; refreshBtn()
        if (!on) saveLayout()
        show(if (on) "EDIT config ${slot + 1}: drag to move, pinch to zoom, double-tap to reset. Touches are NOT sent."
             else "Config ${slot + 1} saved for ${shortName(curPkg)}")
    }

    private fun applyView() { sv.scaleX = scale; sv.scaleY = scale; sv.translationX = tx; sv.translationY = ty }

    // ---------- per-app layouts ----------
    private fun shortName(p: String) = if (p.isEmpty()) "default" else p.substringAfterLast('.')
    private fun key(pkg: String) = if (pkg.isEmpty()) "default" else pkg

    private fun saveLayout() {
        val k = "${key(curPkg)}|$slot"
        getSharedPreferences("layouts", MODE_PRIVATE).edit()
            .putFloat("$k|s", scale).putFloat("$k|x", tx).putFloat("$k|y", ty)
            .putInt("${key(curPkg)}|slot", slot).apply()
    }

    private fun readSlot(p: SharedPreferences) {
        val k = "${key(curPkg)}|$slot"
        val old = slot == 0 // layouts saved by earlier versions count as configuration 1
        scale = p.getFloat("$k|s", if (old) p.getFloat("${key(curPkg)}|s", 1f) else 1f)
        tx = p.getFloat("$k|x", if (old) p.getFloat("${key(curPkg)}|x", 0f) else 0f)
        ty = p.getFloat("$k|y", if (old) p.getFloat("${key(curPkg)}|y", 0f) else 0f)
        applyView()
    }

    /** Switch app: load the configuration that was last used for it. */
    private fun loadLayout(pkg: String) {
        val p = getSharedPreferences("layouts", MODE_PRIVATE)
        curPkg = pkg
        slot = p.getInt("${key(pkg)}|slot", 0).coerceIn(0, 3)
        readSlot(p)
        refreshBtn()
    }

    /** Pick one of the 4 configurations for the current app (works while editing too). */
    private fun setSlot(n: Int) {
        if (n == slot) return
        saveLayout()                       // keep any edits made to the configuration we're leaving
        slot = n
        val p = getSharedPreferences("layouts", MODE_PRIVATE)
        readSlot(p)
        p.edit().putInt("${key(curPkg)}|slot", slot).apply()
        refreshBtn()
        show("Config ${n + 1} · ${shortName(curPkg)}")
    }

    private fun startPoller() {
        if (poller != null) return
        poller = Thread {
            while (alive) {
                if (resumed && !editing) {
                    val pkg = runCatching { svc?.foregroundPackage(topId) }.getOrNull().orEmpty()
                    if (pkg.isNotEmpty() && pkg != curPkg) runOnUiThread {
                        if (!editing) { loadLayout(pkg); show("Layout: ${shortName(pkg)}") }
                    }
                }
                try { Thread.sleep(2000) } catch (ie: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun pickTopDisplay() {
        val dm = getSystemService(DisplayManager::class.java)
        val mine = display?.displayId ?: 0
        val all = dm.displays
        val top = all.firstOrNull { it.displayId == 0 && mine != 0 } ?: all.firstOrNull { it.displayId != mine } ?: return
        topId = top.displayId
        val p = Point(); @Suppress("DEPRECATION") top.getRealSize(p)
        topW = p.x; topH = p.y
    }

    // ---------- touch ----------
    private fun forward(v: View, e: MotionEvent) {
        v.requestUnbufferedDispatch(e)
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (live) ensureRaw(e)
            streamRaw = live && rawOk
        }
        val s = svc ?: return
        if (streamRaw) forwardRaw(s, v, e) else forwardGesture(v, e)
    }

    /** Pick the touch controller of the top screen: the one that is NOT the controller this touch came from. */
    private fun ensureRaw(e: MotionEvent) {
        val s = svc
        if (s == null || !rawReady) { rawOk = false; return }
        val rot = getSystemService(DisplayManager::class.java).getDisplay(topId)?.rotation ?: 0
        if (rawTried && rot == rawRot) return
        rawTried = true; rawRot = rot
        val bottom = InputDevice.getDevice(e.deviceId)?.name
        val names = InputDevice.getDeviceIds().toList().mapNotNull { id ->
            InputDevice.getDevice(id)?.takeIf { it.supportsSource(InputDevice.SOURCE_TOUCHSCREEN) }?.name
        }
        val top = rawName ?: names.firstOrNull { it != bottom }
        if (top == null) { rawOk = false; show("No second touch controller found – using tap/swipe"); return }
        val r = runCatching { s.selectRaw(top, rot, topW, topH) }.getOrElse { "ERR $it" }
        rawOk = r.startsWith("OK"); rawName = if (rawOk) top else null
        show(if (rawOk) "LIVE multi-touch → $top" else "Live touch unavailable: $r – using tap/swipe")
    }

    private fun forwardRaw(s: IMirrorService, v: View, e: MotionEvent) {
        val sx = topW.toFloat() / v.width; val sy = topH.toFloat() / v.height
        val n = e.pointerCount
        val ids = IntArray(n) { e.getPointerId(it) }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { activePtrs.clear(); activePtrs.add(ids[0]) }
            MotionEvent.ACTION_POINTER_DOWN -> activePtrs.add(ids[e.actionIndex])
            MotionEvent.ACTION_POINTER_UP -> activePtrs.remove(ids[e.actionIndex])
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> activePtrs.clear()
        }
        fun send(h: Int) {
            val xs = FloatArray(n) { (if (h < 0) e.getX(it) else e.getHistoricalX(it, h)) * sx }
            val ys = FloatArray(n) { (if (h < 0) e.getY(it) else e.getHistoricalY(it, h)) * sy }
            s.rawTouch(e.action, e.actionIndex, ids, xs, ys)
        }
        if (e.actionMasked == MotionEvent.ACTION_MOVE) for (h in 0 until e.historySize) send(h)
        send(-1)
    }

    private fun cancelRaw() {
        if (activePtrs.isEmpty()) return
        val ids = activePtrs.toIntArray(); val z = FloatArray(ids.size)
        runCatching { svc?.rawTouch(3, 0, ids, z, z) }
        activePtrs.clear()
    }

    /** Fallback: record the gesture, replay it with the system `input` command when the finger lifts. */
    private fun forwardGesture(v: View, e: MotionEvent) {
        val x = (e.getX(0) * topW / v.width).toInt().coerceIn(0, topW - 1)
        val y = (e.getY(0) * topH / v.height).toInt().coerceIn(0, topH - 1)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gx = x; gy = y; gt = e.eventTime; gvx = e.getX(0); gvy = e.getY(0); cancelled = false
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> cancelled = true
            MotionEvent.ACTION_UP -> if (!cancelled) {
                val dur = (e.eventTime - gt).toInt().coerceIn(1, 3000)
                val slop = ViewConfiguration.get(this).scaledTouchSlop * 2
                val still = Math.hypot((e.getX(0) - gvx).toDouble(), (e.getY(0) - gvy).toDouble()) < slop
                val x2 = if (still) gx else x; val y2 = if (still) gy else y
                runCatching { svc?.shellGesture(gx, gy, x2, y2, dur, topId) }
                show(when {
                    still && dur < 400 -> "tap $gx,$gy"
                    still -> "long-press $gx,$gy ${dur}ms"
                    else -> "swipe $gx,$gy → $x2,$y2 ${dur}ms"
                })
            }
        }
    }

    // ---------- mirroring (Shizuku) ----------
    private fun connect() {
        if (!Shizuku.pingBinder()) return
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(0); return }
        if (svc == null) Shizuku.bindUserService(args, conn)
    }

    private fun startMirror() {
        if (surfaceOk) runCatching { svc?.startMirror(sv.holder.surface, topId, topW, topH) }
            .onFailure { show("Mirror failed: $it") }
    }

    override fun surfaceCreated(h: SurfaceHolder) {}
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { surfaceOk = true; startMirror() }
    override fun surfaceDestroyed(h: SurfaceHolder) { surfaceOk = false; runCatching { svc?.stopMirror() } }

    override fun onResume() { resumed = true; super.onResume() }
    override fun onPause() { resumed = false; cancelRaw(); saveLayout(); super.onPause() }

    override fun onDestroy() {
        alive = false; poller?.interrupt()
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeRequestPermissionResultListener(permL)
        runCatching { Shizuku.unbindUserService(args, conn, true) }
        super.onDestroy()
    }

    companion object {
        private const val BLACK = 0xFF000000.toInt()
        private const val CLOSE = 0xFF5C1D0A.toInt()   // very dark orange-red
        private const val ORANGE = 0xFFFF9800.toInt()  // editing layout
    }
}
